var msg = "Bot is working (^o^)"

exports.Hello = () => {
    console.log(msg);
};
